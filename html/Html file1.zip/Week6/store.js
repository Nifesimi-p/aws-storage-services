$('.nav-menu').click(function(){
    $('.nav-list').toggle()
  }) 

